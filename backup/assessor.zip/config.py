#!/usr/bin/python
import os
 
class MSSQL:
    server   = '34.94.71.162' #escape backslash windows
    database = 'master' 
    username = 'myles' 
    password = 'Ptza#56!'