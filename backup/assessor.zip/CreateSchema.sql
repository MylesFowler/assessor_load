/*
drop table property.assessorData;
drop schema property;
*/

CREATE SCHEMA property; 
GO